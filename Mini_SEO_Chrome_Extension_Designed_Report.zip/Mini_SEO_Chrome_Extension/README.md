# Mini SEO Chrome Extension

A beginner-friendly Chrome extension that checks basic on-page SEO for the tab you are viewing and generates a downloadable HTML report.

## Features
- Page title and character count
- Meta description and character count
- H1/H2/H3 heading counts
- Images missing `alt` text
- Canonical URL
- Open Graph title/description
- Basic SEO checklist score
- Generate a designed HTML report with a cover-style header, score summary, checklist table, status badges, and print-friendly layout; open it in Chrome and choose Download / Save as PDF

## Database / backend
No database or PHP backend is required for this version. The extension analyzes the current webpage locally and generates a report in the browser. It does not save reports to a server or maintain audit history.

## Install
1. Extract this ZIP.
2. Open Chrome and go to `chrome://extensions`.
3. Turn on **Developer mode**.
4. Click **Load unpacked**.
5. Select the `extension` folder.
6. Open a normal HTTP/HTTPS website, click the extension icon, and press **Analyze page**.
7. Click **Generate SEO report (HTML)** to download the report.

## Limitations
This is a basic on-page checker, not a full SEO crawler. It cannot provide actual Google rankings, search volume, backlinks, or Core Web Vitals without additional data sources/APIs. Some pages block scripts or render content dynamically, so results may vary.
