// Set this to your deployed HTTPS PHP backend or local XAMPP URL.
let latestReport = null;
const $ = (id) => document.getElementById(id);

$("analyzeBtn").addEventListener("click", async () => {
  $("analyzeBtn").disabled = true;
  $("status").textContent = "Analyzing current page…";
  $("results").classList.add("hidden");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https?:/.test(tab.url || "")) {
      throw new Error("Open a normal HTTP/HTTPS webpage first. Chrome internal pages cannot be analyzed.");
    }
    const injection = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: collectSeoData
    });
    latestReport = injection?.[0]?.result;
    if (!latestReport) throw new Error("Could not read page data. Try refreshing the webpage.");
    latestReport.pageUrl = tab.url;
    latestReport.pageTitle = latestReport.title || tab.title || "";
    renderReport(latestReport);
    $("status").textContent = "Analysis complete: " + new URL(tab.url).hostname;
    $("results").classList.remove("hidden");
  } catch (err) {
    $("status").textContent = err.message || "Unable to analyze this page.";
  } finally {
    $("analyzeBtn").disabled = false;
  }
});

function collectSeoData() {
  const meta = (name, attr = "name") => {
    const node = document.querySelector(`meta[${attr}="${name}"]`);
    return node ? (node.content || "").trim() : "";
  };
  const title = (document.title || "").trim();
  const description = meta("description");
  const h1 = [...document.querySelectorAll("h1")].map(n => (n.innerText || "").trim()).filter(Boolean);
  const h2Count = document.querySelectorAll("h2").length;
  const h3Count = document.querySelectorAll("h3").length;
  const images = [...document.images];
  const missingAlt = images.filter(img => !img.hasAttribute("alt") || !img.getAttribute("alt").trim()).length;
  const canonicalNode = document.querySelector('link[rel="canonical"]');
  const canonical = canonicalNode ? canonicalNode.href : "";
  const ogTitle = meta("og:title", "property");
  const ogDescription = meta("og:description", "property");
  const checks = [
    { key: "title", label: "Page title", pass: title.length > 0, detail: title ? `${title} (${title.length} characters)` : "Missing title" },
    { key: "description", label: "Meta description", pass: description.length > 0, detail: description ? `${description} (${description.length} characters)` : "Missing meta description" },
    { key: "h1", label: "H1 heading", pass: h1.length === 1, detail: `${h1.length} H1 heading(s)${h1[0] ? ": " + h1[0] : ""}` },
    { key: "images", label: "Image alt text", pass: missingAlt === 0, detail: `${missingAlt} of ${images.length} image(s) missing alt text` },
    { key: "canonical", label: "Canonical URL", pass: Boolean(canonical), detail: canonical || "Missing canonical link" },
    { key: "og", label: "Open Graph tags", pass: Boolean(ogTitle && ogDescription), detail: `Title: ${ogTitle ? "present" : "missing"} · Description: ${ogDescription ? "present" : "missing"}` }
  ];
  const score = Math.round(checks.filter(c => c.pass).length / checks.length * 100);
  return {
    title, description, h1, h2Count, h3Count, imagesCount: images.length,
    missingAlt, canonical, ogTitle, ogDescription, checks, score,
    analyzedAt: new Date().toISOString()
  };
}

function renderReport(report) {
  $("score").textContent = report.score;
  $("scoreLabel").textContent = report.score >= 80 ? "Good basics" : report.score >= 50 ? "Needs work" : "Needs attention";
  $("checks").innerHTML = "";
  report.checks.forEach(item => {
    const card = document.createElement("div");
    card.className = "check";
    const top = document.createElement("div");
    top.className = "check-top";
    const name = document.createElement("span");
    name.textContent = item.label;
    const state = document.createElement("span");
    state.className = item.pass ? "ok" : "warn";
    state.textContent = item.pass ? "PASS" : "CHECK";
    const detail = document.createElement("div");
    detail.className = "check-detail";
    detail.textContent = item.detail;
    top.append(name, state);
    card.append(top, detail);
    $("checks").append(card);
  });
}


$("reportBtn").addEventListener("click", () => {
  if (!latestReport) return;
  const esc = (value) => String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[ch]));
  const rows = latestReport.checks.map((item, index) => `
    <tr>
      <td class="number">${String(index + 1).padStart(2, "0")}</td>
      <td><strong>${esc(item.label)}</strong><div class="detail">${esc(item.detail)}</div></td>
      <td><span class="status ${item.pass ? "pass" : "review"}">${item.pass ? "PASS" : "REVIEW"}</span></td>
    </tr>`).join("");
  const scoreLabel = latestReport.score >= 80 ? "Strong foundation" : latestReport.score >= 50 ? "Room to improve" : "Needs attention";
  const reportHtml = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>SEO Audit Report</title>
<style>
:root{--navy:#142e59;--blue:#2463a6;--orange:#ed9a43;--ink:#18253d;--muted:#65738b;--line:#dce4ef;--pale:#f3f6fb;--green:#177245;--greenbg:#e5f5ec;--amber:#9a570a;--amberbg:#fff0db}
*{box-sizing:border-box}
body{margin:0;background:#e9eef5;font-family:Arial,Helvetica,sans-serif;color:var(--ink);line-height:1.45}
.toolbar{max-width:900px;margin:18px auto 0;display:flex;justify-content:flex-end;gap:8px;padding:0 18px}
button{border:0;border-radius:8px;padding:11px 16px;background:var(--navy);color:#fff;font-weight:700;cursor:pointer}
.sheet{max-width:900px;min-height:1120px;margin:16px auto 30px;background:#fff;box-shadow:0 8px 35px #1a31501a}
.cover{background:linear-gradient(130deg,#10264b,#1e4d86);color:#fff;padding:38px 42px 34px;position:relative;overflow:hidden}
.cover:after{content:"";position:absolute;width:230px;height:230px;border:35px solid #ffffff12;border-radius:50%;right:-65px;top:-75px}
.brand{display:flex;align-items:center;gap:10px;font-size:12px;font-weight:800;letter-spacing:2px;text-transform:uppercase}
.brand-mark{width:34px;height:34px;border-radius:9px;background:var(--orange);display:grid;place-items:center;color:var(--navy);font-weight:900;font-size:18px}
.kicker{color:#ffca86;text-transform:uppercase;letter-spacing:2px;font-size:11px;font-weight:800;margin-top:42px}
h1{font-size:37px;line-height:1.12;margin:10px 0 12px;max-width:540px}
.subtitle{color:#dbe7f7;font-size:14px;max-width:570px}
.cover-meta{display:flex;gap:26px;flex-wrap:wrap;margin-top:27px;font-size:11px;color:#dbe7f7}
.cover-meta b{display:block;color:#fff;font-size:12px;margin-top:4px;overflow-wrap:anywhere}
.content{padding:30px 42px 36px}
.section-title{display:flex;align-items:center;gap:10px;margin:0 0 14px;color:var(--navy);font-size:17px}
.section-title:before{content:"";width:5px;height:20px;border-radius:3px;background:var(--orange)}
.summary{display:grid;grid-template-columns:150px 1fr;gap:18px;margin-bottom:28px}
.score-box{border-radius:14px;background:var(--pale);border:1px solid var(--line);padding:18px;text-align:center}
.score{font-size:39px;font-weight:800;color:var(--navy);line-height:1.1}
.outof{font-size:11px;color:var(--muted)}
.score-label{font-size:11px;color:var(--blue);font-weight:800;margin-top:9px}
.summary-text{border:1px solid var(--line);border-radius:14px;padding:17px}
.summary-text h3{font-size:14px;margin:0 0 7px}
.summary-text p{font-size:12px;color:var(--muted);margin:0}
.pills{display:flex;gap:8px;flex-wrap:wrap;margin-top:13px}
.pill{background:#eef3fa;border-radius:20px;padding:6px 9px;font-size:10px;color:#385276;font-weight:700}
table{width:100%;border-collapse:collapse;font-size:12px}
thead th{text-align:left;padding:11px 10px;background:var(--navy);color:#fff;font-size:10px;text-transform:uppercase;letter-spacing:.7px}
tbody td{padding:13px 10px;border-bottom:1px solid var(--line);vertical-align:top}
tbody tr:nth-child(even){background:#f8fafd}
.number{width:44px;color:#7e8ca2;font-weight:800}
.detail{font-size:11px;color:var(--muted);margin-top:4px;overflow-wrap:anywhere}
.status{display:inline-block;border-radius:20px;padding:5px 8px;font-size:9px;font-weight:800;letter-spacing:.4px}
.pass{background:var(--greenbg);color:var(--green)}
.review{background:var(--amberbg);color:var(--amber)}
.note{margin-top:22px;background:#fff7eb;border-left:4px solid var(--orange);padding:13px 15px;border-radius:0 8px 8px 0;font-size:11px;color:#6f512d}
.footer{border-top:1px solid var(--line);margin-top:30px;padding-top:12px;display:flex;justify-content:space-between;gap:12px;color:#8290a5;font-size:10px}
@page{size:A4;margin:12mm}
@media print{
 body{background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}
 .toolbar{display:none}
 .sheet{margin:0;max-width:none;min-height:0;box-shadow:none}
 .cover{padding:28px 32px}
 .content{padding:24px 32px}
 h1{font-size:31px}
 thead{display:table-header-group}
 tr{break-inside:avoid}
}
@media(max-width:620px){.sheet{margin:0}.cover{padding:26px}.content{padding:24px}.summary{grid-template-columns:1fr}.score-box{display:flex;align-items:center;justify-content:center;gap:15px}.kicker{margin-top:30px}h1{font-size:30px}}
</style></head><body>
<div class="toolbar"><button onclick="window.print()">Download / Save as PDF</button></div>
<main class="sheet">
  <section class="cover">
    <div class="brand"><span class="brand-mark">S</span><span>Mini SEO Analyzer</span></div>
    <div class="kicker">Website performance · On-page review</div>
    <h1>SEO Audit<br>Report</h1>
    <div class="subtitle">A quick review of essential on-page SEO elements, with practical checks to help identify areas for improvement.</div>
    <div class="cover-meta">
      <div>WEBSITE<b>${esc(latestReport.pageUrl)}</b></div>
      <div>REPORT DATE<b>${esc(new Date(latestReport.analyzedAt).toLocaleDateString())}</b></div>
    </div>
  </section>
  <section class="content">
    <h2 class="section-title">Executive summary</h2>
    <div class="summary">
      <div class="score-box"><div class="score">${esc(latestReport.score)}</div><div class="outof">OUT OF 100</div><div class="score-label">${esc(scoreLabel)}</div></div>
      <div class="summary-text">
        <h3>${esc(latestReport.pageTitle || latestReport.title || "Untitled webpage")}</h3>
        <p>${esc(latestReport.description || "No meta description was found on this page.")}</p>
        <div class="pills"><span class="pill">${latestReport.checks.filter(c=>c.pass).length} checks passed</span><span class="pill">${latestReport.checks.filter(c=>!c.pass).length} items to review</span><span class="pill">${esc(latestReport.imagesCount)} images scanned</span></div>
      </div>
    </div>
    <h2 class="section-title">On-page SEO checklist</h2>
    <table><thead><tr><th>#</th><th>SEO element and finding</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table>
    <div class="note"><strong>Recommended next step:</strong> Review each item marked “REVIEW”, correct missing or incomplete elements where appropriate, and run the audit again. SEO best practices depend on page purpose and context; this score is a simple checklist, not a Google ranking prediction.</div>
    <div class="footer"><span>Generated by Mini SEO Analyzer</span><span>Basic on-page audit · ${esc(new Date(latestReport.analyzedAt).toLocaleString())}</span></div>
  </section>
</main></body></html>`;
  const blob = new Blob([reportHtml], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "mini-seo-audit-report.html";
  link.click();
  URL.revokeObjectURL(url);
  $("reportStatus").textContent = "Designed report downloaded. Open it in Chrome and click “Download / Save as PDF” to save the formatted PDF.";
});
